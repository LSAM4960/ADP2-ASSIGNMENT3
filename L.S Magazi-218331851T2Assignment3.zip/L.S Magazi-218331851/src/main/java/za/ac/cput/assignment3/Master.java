
package za.ac.cput.assignment3;

/**
 *
 * @ Student Details: Lonwabo Sibusisiwe 218331851
 */
public class Master {
    public static void main(String[] args) {
         RunMaster RunMaster = new RunMaster();
         RunMaster.readFromSerFile();
         RunMaster.sCustomersList();
         RunMaster.formatDob();
         RunMaster.pCustomers();
         RunMaster.sSuppliersList();
         RunMaster.rSuppliers();
    }
}
